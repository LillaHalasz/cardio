package hu.user.kardioapplication;

import android.view.View;

/**
 * Created by User on 2016.04.27..
 */
public interface ItemClickListener
{
    void onClick(View view, int position);
}
