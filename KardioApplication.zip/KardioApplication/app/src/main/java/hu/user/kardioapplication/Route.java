package hu.user.kardioapplication;

/**
 * Created by User on 2016.04.27..
 */
public class Route
{
    String name;
    String description;

    public Route(String name, String description)
    {
        this.name = name;
        this.description = description;
    }
}
